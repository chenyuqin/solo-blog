title: Coody Framework框架初发现
date: '2019-09-19 19:02:44'
updated: '2019-09-19 19:02:44'
tags: [Java]
permalink: /articles/2019/09/19/1568890964746.html
---
[Coody Framework](https://gitee.com/coodyer/Coody-Framework "Coody Framework") 是致力于研发国产 IoC 框架，主打轻、简、快特征，已登录 Maven 中央仓库，代码托管在码云，地址是[https://gitee.com/coodyer/Coody-Framework](https://gitee.com/coodyer/Coody-Framework) ，作者是 Coody。

本篇文章主要是贴一小点代码，可能无任何用处，而且还有可能有错误！毕竟水平有限，所以谨慎观看！

首先是 coody-web 包下的 CoodyServletListen 类，这个类实现了 ServletContextListener 类。众所周知（当然我是查的），ServletContextListener 类能够监听 ServletContext 对象的生命周期，实际上就是监听 Web 应用的生命周期。当 Servlet 容器启动或终止 Web 应用时，会触发 ServletContextEvent 事件，该事件由 ServletContextListener 来处理。在 ServletContextListener 接口中定义了处理 ServletContextEvent 事件的两个方法，分别是 contextDestroyed 和 contextInitialized。
我之前思考的时候有个问题，就是思考的时候思想总是停留在代码层面，然后就觉得注入应该在代码中我们去主动拦截，然后又需要拦截器之类的云云，有点说不清。像这个项目，一开始就设定在了 Tomcat 之类的容器启动的时候去执行，对我来说感觉有点超前呢 ~
言归正传，以下是 Coody 在 contextInitialized 做的事情：

```
@Override
public void contextInitialized(ServletContextEvent event) {
	try {
		String config = event.getServletContext().getInitParameter("configPath");
		if (StringUtil.isNullOrEmpty(config)) {
			throw new InitException("配置为空 >>configPath");
		}
		ConfigBuilder.builder(config);
		//载入框架配置
		CoodyConfig coodyConfig=new CoodyConfig();
		coodyConfig.init();
		//框架启动
		CoreApp.init(coodyConfig);
	} catch (Exception e) {
		e.printStackTrace();
	}
}
```
① 首先会去web.xml中获取configPath参数的值。（其实我不知道这个configPath里面究竟放的什么鬼）
```
String config = event.getServletContext().getInitParameter("configPath");
```
```
  <!-- web.xml中：初始化加载配置文件目录 -->
  <context-param>
    <param-name>configPath</param-name>
    <param-value>config</param-value>
  </context-param>
```
② 然后调用ConfigBuilder.builder(config)方法。
```
public static void builder(String... dirs) throws IOException, URISyntaxException {
	for (String dir : dirs) {
		Enumeration<URL> urls = ConfigBuilder.class.getClassLoader().getResources(dir);
		if (StringUtil.isNullOrEmpty(urls)) {
			return;
		}
		while (urls.hasMoreElements()) {
			URL url = (URL) urls.nextElement();
			File file = new File(url.toURI());
			loadPropertByDir(file);
		}
	}
}
```
String... dirs就是上一步得出的configPath的值了，照这么看应该就是一些路径，而且可能还不止一个！然后呢，就是调用ClassLoader.getResources(dir)从classpath下面获取该路径下的所有文件了。
而对于每一个dirs -> dir -> urls -> url呢，其实就是一个文件或者目录，接下来就是调用loadPropertByDir方法了，在下面：
```
private static void loadPropertByDir(File file) throws URISyntaxException, IOException {
	if (!file.isDirectory()) {
		FileInputStream inStream = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(inStream);
		Enumeration<Object> keys = prop.keys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = prop.getProperty(key);
			if (StringUtil.hasNull(key, value)) {
				value = "";
			}
			config.put(key, value.trim());
		}
		return;
	}
	String[] files = file.list();
	if (StringUtil.isNullOrEmpty(files)) {
		return;
	}
	for (String filePath : files) {
		String path = file.getPath() + File.separator + filePath;
		File childFile = new File(path);
		loadPropertByDir(childFile);
	}
}
```
这个方法会把得到的所有文件的里面的键值对数据存放起来，存放的 ConfigBuilder.config中。
```
private static Map<String, String> config = new HashMap<String, String>();
```
③ 存放完你的所有设置的数据之后呢（其实我也不知道是不是这样理解的- -），会去调用下面两行代码 ：
```
//载入框架配置
CoodyConfig coodyConfig=new CoodyConfig();
coodyConfig.init();
```
作者注释写了，载入框架配置！嗯，很霸气！据我理解呢，它就是对我们上一步设置的config中提取需要的参数出来，为下一步做准备的。这里涉及到CoodyConfig中的两个字段：
```
/**
 * 扫描的包配置
 */
public String packager = "org.coody.framework";

/**
 * 要启动的组件
 */
public String assember = "";
```
这两个字段在CoodyConfi.init()方法中用到了：
```
public void init() throws IllegalArgumentException, IllegalAccessException, IOException, URISyntaxException {
	Field[] fields = this.getClass().getDeclaredFields();
	for (Field field : fields) {
		if (Modifier.isFinal(field.getModifiers())) {
			continue;
		}
		String configField = PREFIX + "." + field.getName();
		String configValue = ConfigBuilder.getProperty(configField);
		if (StringUtil.isNullOrEmpty(configValue)) {
			continue;
		}
		field.setAccessible(true);
		String defaulltValue = (String) field.get(this);
		if (StringUtil.isNullOrEmpty(defaulltValue)) {
			field.set(this, configValue);
			continue;
		}
		configValue = defaulltValue + "," + configValue;
		field.set(this, configValue);
	}
}
```
这个方法针对的字段field是非final的，而整个CoodyConfig类中的非final字段就是我上面提的两个。PREFIX这个常量是coody来的。
也就是说，组装coody.packager和coody.assember，从我们上一步存放的config中找，找这两个兔崽子，如果找到了，就加在原本的值后面。
总的来说呢，估计就是例如你配置了你要扫描哪些包或者组件，我就把它加到CoodyConfig这个类的字段上面，之后跟我本来就有的一起加载。
④ contextInitialized方法的最后一步呢，就是启动框架了，这一步做的事情还是很有意思的。
```
//框架启动
CoreApp.init(coodyConfig);
```
首先呢，看一下CoreApp.init()方法：
 ```
public static void init(CoodyConfig config) throws Exception {
	// 初始化组建加载器
	List<Class<?>> loaders = initLoader(config.assember);
	// 初始化扫描类
	Set<Class<?>> clazzs = initScanner(config.packager);
	
	BeanContainer.setClazzContainer(clazzs);
	// 进行加载操作
	long tInit = System.currentTimeMillis();
	for (Class<?> loader : loaders) {
		logger.info(loader.getName() + " >>开始加载");
		long t0 = System.currentTimeMillis();
		CoodyLoader icopLoader = (CoodyLoader) loader.newInstance();
		icopLoader.doLoader();
		long t1 = System.currentTimeMillis();
		logger.info(loader.getName() + " >>加载耗时:" + (t1 - t0) + "ms");
	}
	long tEnd = System.currentTimeMillis();
	logger.info("Coody Framework >>加载耗时:" + (tEnd - tInit) + "ms");
}
```
它首先呢，会去调用本类的两个静态方法：
```
// 初始化组建加载器
List<Class<?>> loaders = initLoader(config.assember);
// 初始化扫描类
Set<Class<?>> clazzs = initScanner(config.packager);
```
正如作者的注释所写，初始化组件加载器和初始化扫描类，这两个方法的参数是不是很熟悉，就是我们上一步重点关照的两个兔崽子啊！
放一下这两个方法的代码，代码很长，真的很长，不过呢，关我屁事哦，爱看不看。
```
@SuppressWarnings("serial")
static Map<Integer, List<Class<?>>> loadersMap = new TreeMap<Integer, List<Class<?>>>() {
	{
		put(1, Arrays.asList(new Class<?>[] { AspectLoader.class }));
		put(2, Arrays.asList(new Class<?>[] { CustomBeanLoader.class }));
		put(3, Arrays.asList(new Class<?>[] { BeanLoader.class }));
		put(4, Arrays.asList(new Class<?>[] { FieldLoader.class }));
		put(Integer.MAX_VALUE, Arrays.asList(new Class<?>[] { InitRunLoader.class }));
	}
};

public static List<Class<?>> initLoader(String assember) throws ClassNotFoundException {
	String[] loaders = assember.split(",");
	for (String loader : loaders) {
		if(StringUtil.isNullOrEmpty(loader)){
			continue;
		}
		Class<?> loaderClazz = Class.forName(loader.trim());
		if (!CoodyLoader.class.isAssignableFrom(loaderClazz)) {
			throw new CoodyException(loaderClazz.getName() + "不是加载器");
		}
		Integer seq = Integer.MAX_VALUE - 1;
		Order order =loader.getClass().getAnnotation(Order.class);
		if (order != null) {
			seq = order.value();
		}
		if (!loadersMap.containsKey(seq)) {
			loadersMap.put(seq, new ArrayList<Class<?>>());
		}
		loadersMap.get(seq).add(loaderClazz);
	}
	List<Class<?>> currentLoaders = new ArrayList<Class<?>>();
	for (Integer key : loadersMap.keySet()) {
		for (Class<?> clazz : loadersMap.get(key)) {
			if (currentLoaders.contains(clazz)) {
				continue;
			}
			currentLoaders.add(clazz);
		}
	}
	if (StringUtil.isNullOrEmpty(currentLoaders)) {
		throw new InitException("加载器为空");
	}
	return currentLoaders;
}

public static Set<Class<?>> initScanner(String packager) {
	// 加载扫描包列表
	String[] packets = packager.split(",");
	Set<Class<?>> clazzs = new HashSet<Class<?>>();
	for (String packet : packets) {
		Set<Class<?>> clazzsTemp = ClassUtil.getClasses(packet);
		clazzs.addAll(clazzsTemp);
	}
	if (StringUtil.isNullOrEmpty(clazzs)) {
		throw new InitException("扫描类为空");
	}
	return clazzs;
}
```
这里初始化返回的loader呢有多个，例如AspectLoader、CustomBeanLoader、BeanLoader、FieldLoader和InitRunLoader（其实我没看太懂这些loader，所以想知道的自己去下源码研究吧），还有一些你自己写在configPath中的loader，这些loader有些是关系切面的，有些是关系字段的，有些就是bean的，当然我说的是废话，毕竟你从类名都能看出来了...
这里初始化扫描的类呢，包括作者本身定义在packager这个字段值对应的包下的所有的类，还包括你定义的coody.packager值包下的所有的类，之后会对这些类搞事情就是了。找到所有的类之后，会把这些类先放在BeanContainer.clazzContainer中：
```
private static Set<Class<?>> clazzContainer = new HashSet<Class<?>>();
```
之后呢，就开始进行加载操作了，对所有加载器loader调用其doLoader()方法。

接下来说一个loader的实现和作用。
下面是所有loader的结构，CoodyLoader是主接口：
![image.png](https://img.hacpai.com/file/2019/09/image-94e3c05e.png)
BeanLoader类的代码如下：
```
/**
 * Bean加载器
 * 
 * @author Coody
 *
 */
public class BeanLoader implements CoodyLoader {
	@Override
	public void doLoader() throws Exception {
		if (StringUtil.isNullOrEmpty(BeanContainer.getClazzContainer())) {
			return;
		}
		for (Class<?> clazz : BeanContainer.getClazzContainer()) {
			if (clazz.isAnnotation()) {
				continue;
			}
			if (StringUtil.isNullOrEmpty(clazz.getAnnotations())) {
				continue;
			}
			Annotation autoBuild = PropertUtil.getAnnotation(clazz, AutoBuild.class);
			if (StringUtil.isNullOrEmpty(autoBuild)) {
				continue;
			}
			BeanAssember.initBean(clazz);
		}
	}
}
```
BeanContainer.getClazzContainer()就是我们上一步存放所有你想要的和作者想要的类的地方了，就是clazzContainer那个字段。
这里会取出所有的类，逐一判断，看这个类是不是注解冒充的，如果不是注解冒充的，那这个类包不包含AutoBuild这个注解。总的来说，就是要你是类，还要包含AutoBuild这个注解。为什么要这些呢？因为我要对你开始实例化了。
只要你满足了上面说的条件，那我就对你执行BeanAssember.initBean(clazz)这个方法。没错，就是它，你看看它的方法名，是不是很明显，简直不能再明显了！
下面是这个方法实现：
```
public static <T> T initBean(Class<?> cla, String additionBeanName, Map<String, Object> parameterMap) {
	Set<String> names = BeanContainer.getOverallBeanName(cla);
	if (!StringUtil.isNullOrEmpty(additionBeanName)) {
		names.add(additionBeanName);
	}
	if (StringUtil.isNullOrEmpty(names)) {
		throw new BeanNameCreateException(cla);
	}
	Object bean = proxy.getProxy(cla, parameterMap);
	if (bean == null) {
		throw new BeanInitException(cla);
	}
	for (String beanName : names) {
		if (StringUtil.isNullOrEmpty(beanName)) {
			continue;
		}
		logger.debug("初始化Bean >>" + beanName + ":" + cla.getName());
		BeanContainer.setBean(beanName, bean);
	}
	if (StringUtil.isNullOrEmpty(parameterMap)) {
			// 启动字节码加速
			ParameterNameUtil.doExecutable(cla);
		}
		return (T) bean;
	}
```
在这个方法里，它会先去判断要实例化的bean类是不是java相关的、是不是CGLib生成的（区别是$$），然后还要考虑这个要实例化的bean类的接口和父类，因为你要初始化一个类，首先需要初始化其父类，而且还要保存你给这个bean类起的名字，最后再用CGLib来动态创建bean类。（此处省略1w字，因为有些难以理解，不知道该怎么看，该怎么说）

最后，贴一下CGLib的一大串代码把，其实我没理解- -：
```
public Object getProxy(Class<?> clazz, Map<String, Object> parameterMap) {
	try {
		Integer modifier = clazz.getModifiers();
		if (Modifier.isAbstract(modifier)) {
			return null;
		}
		if (Modifier.isInterface(modifier)) {
			return null;
		}
		MappedConstructor mappedConstructor = getConstructor(clazz, parameterMap);
		if (!hasProxy(clazz)) {
			try {
				return mappedConstructor.getConstructor().newInstance(mappedConstructor.getParameters());
			} catch (Exception e) {
				throw new BeanInitException(clazz, e);
			}
		}
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(clazz);
		enhancer.setCallback(this);
		if (StringUtil.isNullOrEmpty(mappedConstructor.getTypes())) {
			return enhancer.create();
		}
		return enhancer.create(mappedConstructor.getTypes(), mappedConstructor.getParameters());
	} catch (Exception e) {
		throw new BeanInitException(clazz, e);
	}

}

public MappedConstructor getConstructor(Class<?> clazz, Map<String, Object> parameterMap) {
	if (StringUtil.isNullOrEmpty(parameterMap)) {
		MappedConstructor mappedConstructor = new MappedConstructor();
		for (Constructor<?> constructor : clazz.getConstructors()) {
			if (constructor.getParameterCount() > 0) {
				continue;
			}
			mappedConstructor.setConstructor(constructor);
		}
		if (mappedConstructor.getConstructor() == null) {
			throw new MappedExecutableException(clazz, parameterMap.keySet());
		}
		return mappedConstructor;
	}
	Map<Executable, List<String>> executableParameters = ParameterNameUtil.getExecutableParameters(clazz);
	if (StringUtil.isNullOrEmpty(executableParameters)) {
		throw new MappedExecutableException(clazz, parameterMap.keySet());
	}
	List<String> inputParameters = new ArrayList<String>(parameterMap.keySet());
	Collections.sort(inputParameters);

	checkExecutable: for (Executable executable : executableParameters.keySet()) {
		if (!(executable instanceof Constructor)) {
			continue checkExecutable;
		}
		List<String> defParameters = executableParameters.get(executable);
		if (defParameters.size() != parameterMap.size()) {
			continue checkExecutable;
		}
		List<String> tempParameters = new ArrayList<String>(defParameters);
		Collections.sort(tempParameters);
		for (int i = 0; i < tempParameters.size(); i++) {
			if (!tempParameters.get(i).equals(inputParameters.get(i))) {
				continue checkExecutable;
			}
		}
		MappedConstructor mappedConstructor = new MappedConstructor();
		mappedConstructor.setConstructor((Constructor<?>) executable);
		mappedConstructor.setTypes(executable.getParameterTypes());
		Object[] parameterValues = new Object[defParameters.size()];
		for (int i = 0; i < defParameters.size(); i++) {
			Object value = parameterMap.get(defParameters.get(i));
			parameterValues[i] =PropertUtil.parseValue(value,mappedConstructor.getTypes()[i]);
		}
		mappedConstructor.setParameters(parameterValues);
		return mappedConstructor;
	}
	throw new MappedExecutableException(clazz, parameterMap.keySet());
}

private boolean hasProxy(Class<?> clazz) {
	Set<Method> methods = PropertUtil.getMethods(clazz);
	if (StringUtil.isNullOrEmpty(methods)) {
		return false;
	}
	boolean needProxy = false;
	for (Method method : methods) {
		for (List<AspectEntity> aspectEntitys : FrameworkConstant.ASPECT_MAP.values()) {
			for (AspectEntity aspectEntity : aspectEntitys) {
				if (!needProxy(clazz, aspectEntity, method)) {
					continue;
				}
				if (InterceptContainer.INTERCEPT_MAP.containsKey(method)) {
					InterceptContainer.INTERCEPT_MAP.get(method).add(aspectEntity);
					needProxy = true;
					continue;
				}
				Set<AspectEntity> aspectMethods = new HashSet<AspectEntity>();
				aspectMethods.add(aspectEntity);
				InterceptContainer.INTERCEPT_MAP.put(method, aspectMethods);
			}
			needProxy = true;
		}
	}
	return needProxy;
}

private boolean needProxy(Class<?> clazz, AspectEntity aspectEntity, Method method) {
	/**
	 * 判断类名是否满足条件
	 */
	if (!StringUtil.isNullOrEmpty(aspectEntity.getClassMappath())) {
		if (!AntUtil.isAntMatch(clazz.getName(), aspectEntity.getClassMappath())) {
			return false;
		}
	}
	/**
	 * 判断方法名是否满足条件
	 */
	if (!StringUtil.isNullOrEmpty(aspectEntity.getMethodMappath())) {
		if (!AntUtil.isAntMatch(MethodSignUtil.getMethodUnionKey(method), aspectEntity.getMethodMappath())) {
			return false;
		}
	}
	/**
	 * 判断注解是否满足条件
	 */
	if (!StringUtil.isNullOrEmpty(aspectEntity.getAnnotationClass())) {
		Annotation[] annotations = method.getAnnotations();
		if (StringUtil.isNullOrEmpty(annotations)) {
			return false;
		}
		List<Class<?>> annotationClazzs = new ArrayList<Class<?>>();
		for (Annotation annotation : annotations) {
			annotationClazzs.add(annotation.annotationType());
		}
		for (Class<?> aspectAnnotationClazz : aspectEntity.getAnnotationClass()) {
			if (!annotationClazzs.contains(aspectAnnotationClazz)) {
				return false;
			}
		}
	}
	return true;
}

@SuppressWarnings("serial")
public static class MappedConstructor extends BaseModel {

	private Constructor<?> constructor;

	private Class<?>[] types;

	private Object[] parameters;

	public Constructor<?> getConstructor() {
		return constructor;
	}

	public void setConstructor(Constructor<?> constructor) {
		this.constructor = constructor;
	}

	public Class<?>[] getTypes() {
		return types;
	}

	public void setTypes(Class<?>[] executable) {
		this.types = executable;
	}

	public Object[] getParameters() {
		return parameters;
	}

	public void setParameters(Object[] parameters) {
		this.parameters = parameters;
	}

}
```

后面的估计我看不下去了，等我哪天修炼有成再来闯关，如果各位觉得上面哪里错了，请各位相信自己，保持怀疑的态度，因为我也怀疑上面哪里可能错了，虽然上面说得很浅，但是，菜就完事了！哈哈哈哈哈👎 -1

