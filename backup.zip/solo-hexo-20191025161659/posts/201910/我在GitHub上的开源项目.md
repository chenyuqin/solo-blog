title: 我在 GitHub 上的开源项目
date: '2019-10-06 16:06:58'
updated: '2019-10-06 16:06:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [ResumeSystem](https://github.com/chenyuqin/ResumeSystem) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/chenyuqin/ResumeSystem/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/chenyuqin/ResumeSystem/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/chenyuqin/ResumeSystem/network/members "分叉数")</span>

简历管理系统



---

### 2. [solo-blog](https://github.com/chenyuqin/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/chenyuqin/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/chenyuqin/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/chenyuqin/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://47.103.68.43:8080`](http://47.103.68.43:8080 "项目主页")</span>

星空之下☪ - Emmmm......



---

### 3. [BookStoreAdmin](https://github.com/chenyuqin/BookStoreAdmin) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/chenyuqin/BookStoreAdmin/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/chenyuqin/BookStoreAdmin/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/chenyuqin/BookStoreAdmin/network/members "分叉数")</span>

网上图书超市  后台系统



---

### 4. [BookMarket](https://github.com/chenyuqin/BookMarket) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/chenyuqin/BookMarket/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/chenyuqin/BookMarket/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/chenyuqin/BookMarket/network/members "分叉数")</span>

网上图书超市



---

### 5. [SpringCloudLearning](https://github.com/chenyuqin/SpringCloudLearning) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/chenyuqin/SpringCloudLearning/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/chenyuqin/SpringCloudLearning/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/chenyuqin/SpringCloudLearning/network/members "分叉数")</span>

SpringCloud学习，代码摘自CSDN博客专栏《史上最简单springcloud教程》

